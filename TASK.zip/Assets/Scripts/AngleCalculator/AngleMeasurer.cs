﻿using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;
using UnityEngine.UI; // Needed for the Image component

public class AngleMeasurer : MonoBehaviour
{
    [SerializeField]
    private InputActionReference clickAction;
    public List<Vector3> clickPoints = new List<Vector3>();
    private LineRenderer lineRenderer;
    public TMPro.TextMeshProUGUI angleText;
    public Button resetButton;

    [Header("Angle Arc UI")]
    [SerializeField] private GameObject angleArcCanvas;
    [SerializeField] private Image angleArcImage;
    [SerializeField] private float arcSizeWorld = 1f;

    private const float LINE_OFFSET = 0.01f;

    void Awake()
    {
        if (clickAction != null)
        {
            clickAction.action.performed += OnClickPerformed;
        }
    }

    void OnEnable()
    {
        if (angleText != null) angleText.text = "Angle: ...";

        resetButton.onClick.AddListener(ResetLines);
        clickAction?.action.Enable();
    }

    void OnDisable()
    {
        resetButton.onClick.RemoveAllListeners();
        clickAction?.action.Disable();
    }

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        if (lineRenderer == null)
        {
            lineRenderer = gameObject.AddComponent<LineRenderer>();
        }

        lineRenderer.positionCount = 0;
        lineRenderer.startWidth = 0.1f;
        lineRenderer.endWidth = 0.1f;
        lineRenderer.sortingOrder = 1;

        if (angleArcCanvas != null)
        {
            angleArcCanvas.SetActive(false);
        }

        if (angleArcImage != null && angleArcImage.type != Image.Type.Filled)
        {
            Debug.LogError("The Angle Arc Image Type must be set to 'Filled' in the Inspector!");
        }
    }

    private void ResetLines()
    {
        clickPoints.Clear();
        lineRenderer.positionCount = 0;
        if (angleText != null) angleText.text = "Angle: ...";
        if (angleArcCanvas != null) angleArcCanvas.SetActive(false);
    }

    private void OnClickPerformed(InputAction.CallbackContext context)
    {
        HandleClick();
    }

    private void HandleClick()
    {
        Vector2 screenPosition = Mouse.current.position.ReadValue();
        Ray ray = Camera.main.ScreenPointToRay(screenPosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit))
        {
            Vector3 newPoint = hit.point;

            if (clickPoints.Count < 3)
            {
                clickPoints.Add(newPoint);
            }
            else
            {
                return;
            }

            UpdateLineRenderer();

            if (clickPoints.Count == 3)
            {
                CalculateAndDisplayAngle();
            }
            else
            {
                if (angleArcCanvas != null) angleArcCanvas.SetActive(false); 
            }
        }
    }

    private void UpdateLineRenderer()
    {
        lineRenderer.positionCount = clickPoints.Count;

        Vector3 offset = Vector3.up * LINE_OFFSET;

        for (int i = 0; i < clickPoints.Count; i++)
        {
            lineRenderer.SetPosition(i, clickPoints[i] + offset);
        }
    }

    private void CalculateAndDisplayAngle()
    {
        if (clickPoints.Count < 3) return;

        Vector3 A = clickPoints[0];
        Vector3 B = clickPoints[1]; 
        Vector3 C = clickPoints[2];

        Vector3 vectorBA = A - B;
        Vector3 vectorBC = C - B;

        float angleInDegrees = Vector3.Angle(vectorBA, vectorBC);

        // Display the result
        string angleResult = $"Angle: {angleInDegrees:F2}°";
        if (angleText != null)
        {
            angleText.text = angleResult;
        }
        else
        {
            Debug.Log(angleResult);
        }

        // Draw the arc using the new UI method
        DrawAngleArcUI(B, vectorBA.normalized, vectorBC.normalized, angleInDegrees);
    }


    private void DrawAngleArcUI(Vector3 vertexPoint, Vector3 directionA, Vector3 directionC, float angle)
    {
        if (angleArcCanvas == null || angleArcImage == null) return;

        // 1. Position the Canvas at the vertex
        angleArcCanvas.transform.position = vertexPoint + (Vector3.up * (LINE_OFFSET + 0.005f));

        // 2. Set the arc rotation

        // Calculate the angle of directionA in the XZ plane relative to the World X-axis.
        float rotationY = Mathf.Atan2(directionA.x, directionA.z) * Mathf.Rad2Deg;

        // Create a rotation that only rotates around the World Y-axis.
        Quaternion flatRotation = Quaternion.Euler(0, rotationY, 0);

        // Apply a 90-degree offset to align the Image's 'Right' (Local +X) axis with directionA.
        // Since the Image component starts filling from its local +X (Right), we must ensure 
        // that the Canvas's local +X is pointing along directionA.
        // NOTE: If you set FillOrigin to 'Bottom', the offset is usually -90 or +90 depending on image orientation.
        // With FillOrigin: Right, a common offset is -90 degrees around the Y-axis. Try +90 if -90 doesn't work.
        Quaternion finalRotation = flatRotation * Quaternion.Euler(90, -90f, 0);

        angleArcCanvas.transform.rotation = finalRotation;

        // 3. Set the scale
        angleArcCanvas.transform.localScale = Vector3.one * arcSizeWorld;

        // 4. Set the Fill Amount
        angleArcImage.fillAmount = angle / 360f;

        angleArcCanvas.SetActive(true);
    }
}