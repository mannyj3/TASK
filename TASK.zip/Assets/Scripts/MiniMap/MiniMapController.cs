using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

public class MinimapController : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    // --- Public Variables (Assign in Inspector) ---
    public Camera mainCamera;
    public Camera minimapCamera;
    public RectTransform minimapRect;
    public Image hoverSprite;
    public float minimapWorldHeight = 100f;

    // --- Private Variables ---
    private RawImage rawImage;
    // NEW: Store the camera used by the Event System
    private Camera eventCamera;

    void Start()
    {
        rawImage = GetComponent<RawImage>();

        if (hoverSprite != null)
        {
            hoverSprite.gameObject.SetActive(false);
            float rectSize = minimapRect.rect.width * 0.4f;
            hoverSprite.rectTransform.sizeDelta = new Vector2(rectSize, rectSize);
        }

        if (minimapCamera != null && minimapCamera.orthographic)
        {
            minimapWorldHeight = minimapCamera.orthographicSize * 2f;
        }
    }

    // --- Event Handlers ---

    public void OnPointerEnter(PointerEventData eventData)
    {
        // FIX 1: Store the camera when the pointer enters!
        eventCamera = eventData.pressEventCamera;

        if (hoverSprite != null)
        {
            hoverSprite.gameObject.SetActive(true);
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        // Clear the camera reference when we leave
        eventCamera = null;

        if (hoverSprite != null)
        {
            hoverSprite.gameObject.SetActive(false);
        }
    }

    // --- Update Method ---
    void Update()
    {
        // Only update the hover box position if the sprite is active 
        if (hoverSprite != null && hoverSprite.gameObject.activeInHierarchy)
        {
            Vector2 localPoint;

            // FIX 2: Use the stored 'eventCamera' instead of the missing 'eventData.pressEventCamera'
            // If eventCamera is null, it defaults to the Screen space.
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(minimapRect, Mouse.current.position.ReadValue(), eventCamera, out localPoint))
            {
                // Position the hover sprite at the mouse cursor's local position
                hoverSprite.rectTransform.localPosition = localPoint;
            }
        }
    }

    // --- Click Handler (This was already correct) ---
    public void OnPointerClick(PointerEventData eventData)
    {
        if (minimapCamera == null || mainCamera == null) return;

        Vector2 localPoint;
        // 1. Convert click screen position to local position within the Minimap UI element
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(minimapRect, eventData.position, eventData.pressEventCamera, out localPoint))
        {
            // 2. Normalize the local coordinates (from -rect.width/2 to +rect.width/2) to the range 0.0 to 1.0
            float normalizedX = (localPoint.x / minimapRect.rect.width) + 0.5f;
            float normalizedY = (localPoint.y / minimapRect.rect.height) + 0.5f;

            // 3. Convert normalized coordinates to world coordinates (relative to the minimap camera's center)

            float worldWidth = minimapWorldHeight * minimapCamera.aspect;
            float worldHalfWidth = worldWidth / 2f;
            float worldHalfHeight = minimapWorldHeight / 2f;

            // Calculate the position offset from the minimap camera's center point
            float worldClickX = (normalizedX * worldWidth) - worldHalfWidth;
            float worldClickY = (normalizedY * minimapWorldHeight) - worldHalfHeight; // UI Vertical Position

            // 4. Calculate the target World Position
            Vector3 minimapCamPos = minimapCamera.transform.position;

            // FIX 3: Map UI X to World X, and UI Y (Vertical) to World Z (Depth).
            Vector3 worldPosition = new Vector3(
                minimapCamPos.x + worldClickX, // X position in the world
                0f,                            // Target height is usually 0 (ground level)
                minimapCamPos.z + worldClickY  // Z position in the world (mapped from UI Y)
            );

            // 5. Move the Main Camera to the calculated world position
            Vector3 newCameraPosition = new Vector3(
                worldPosition.x,
                mainCamera.transform.position.y, // Preserve the main camera's current height (Y)
                worldPosition.z
            );

            mainCamera.transform.position = newCameraPosition;

        }
    }
}