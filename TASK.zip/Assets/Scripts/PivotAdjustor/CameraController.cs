using UnityEngine;
using UnityEngine.InputSystem; // REQUIRED for the new input system

/// <summary>
/// Controls a camera that orbits around a designated target (the "Pivot") 
/// using the NEW Unity Input System and InputActionReference for Inspector assignment.
/// </summary>
public class CameraController: MonoBehaviour
{
    // --- Public Settings (Adjust in Inspector) ---

    [Header("Target & Distance")]
    [Tooltip("The GameObject the camera will orbit around. Should be named 'Pivot'.")]
    public Transform target;
    public float distance = 10.0f; // Initial distance from the target

    [Header("Rotation")]
    public float rotationSpeed = 0.5f; // Lower speed for delta input
    public float yMinLimit = -20f;
    public float yMaxLimit = 80f;

    [Header("Zoom")]
    public float zoomSpeed = 0.005f; // Lower speed for scroll input
    public float minDistance = 2.0f;
    public float maxDistance = 50.0f;

    // --- Input Action References (ASSIGN THESE IN THE INSPECTOR) ---
    // Drag the corresponding actions from your 'CameraActions' asset here.
    [Header("Input Action References")]
    [Tooltip("Mouse Delta (Look)")]
    public InputActionReference lookAction;
    [Tooltip("Mouse Scroll Wheel (Zoom)")]
    public InputActionReference zoomAction;
    [Tooltip("Right Mouse Button (Enable Orbit)")]
    public InputActionReference enableOrbitAction;
    [Tooltip("'R' Key (Reset View)")]
    public InputActionReference resetViewAction;

    // --- Private Variables ---
    private float xRot = 0.0f;
    private float yRot = 0.0f;
    private const float defaultDistance = 10.0f;
    private const float defaultXRot = 45.0f;
    private const float defaultYRot = 45.0f;

    // --- Unity Lifecycle Methods ---

    void Start()
    {
        // 1. Find the Pivot GameObject
        if (target == null)
        {
            GameObject pivotObject = GameObject.Find("Pivot");
            if (pivotObject != null)
            {
                target = pivotObject.transform;
            }
            else
            {
                Debug.LogError("OrbitCameraControllerNewInput Error: Could not find a GameObject named 'Pivot'. Please ensure your pivot object is correctly named.");
                enabled = false; // Disable the script if no target is found
                return;
            }
        }

        // --- FIX: Initialize rotation based on current position relative to target to prevent jumping ---

        // Calculate the initial vector from the target to the camera
        Vector3 offsetVector = transform.position - target.position;

        // Set initial distance to the current magnitude
        distance = offsetVector.magnitude;

        // Calculate the initial rotation required to look along this vector
        // Quaternion.LookRotation(vector) gives the rotation that faces along 'vector'
        Quaternion initialRotation = Quaternion.LookRotation(offsetVector);

        // Extract clean Euler angles (Pitch and Yaw)
        Vector3 initialAngles = initialRotation.eulerAngles;

        // Yaw (XRot) is rotation around the Y-axis
        xRot = initialAngles.y;

        // Pitch (YRot) is rotation around the X-axis. We must adjust for the 0-360 wrap.
        yRot = initialAngles.x;
        if (yRot > 180f)
        {
            yRot -= 360f; // Convert high positive values (e.g., 350) to negative (e.g., -10)
        }

        ResetRotationLimits();

        // UpdateCameraPosition() is called here to apply the initial state and clamping
        UpdateCameraPosition();

        // Subscribe to the Reset Action event using the .action property of the reference
        if (resetViewAction != null && resetViewAction.action != null)
        {
            resetViewAction.action.performed += OnResetViewPerformed;
        }
    }

    // Must enable and disable actions in these methods
    private void OnEnable()
    {
        // Enable actions using the .action property
        if (lookAction != null && lookAction.action != null) lookAction.action.Enable();
        if (zoomAction != null && zoomAction.action != null) zoomAction.action.Enable();
        if (enableOrbitAction != null && enableOrbitAction.action != null) enableOrbitAction.action.Enable();
        if (resetViewAction != null && resetViewAction.action != null) resetViewAction.action.Enable();
    }

    private void OnDisable()
    {
        // Disable actions using the .action property
        if (lookAction != null && lookAction.action != null) lookAction.action.Disable();
        if (zoomAction != null && zoomAction.action != null) zoomAction.action.Disable();
        if (enableOrbitAction != null && enableOrbitAction.action != null) enableOrbitAction.action.Disable();
        if (resetViewAction != null && resetViewAction.action != null) resetViewAction.action.Disable();

        // Unsubscribe to prevent memory leaks if actions are being used by events
        if (resetViewAction != null && resetViewAction.action != null)
        {
            resetViewAction.action.performed -= OnResetViewPerformed;
        }
    }

    void LateUpdate()
    {
        if (target == null) return;

        // 1. Handle Rotation (Orbiting)
        HandleRotation();

        // 2. Handle Zooming (Distance Change)
        HandleZoom();

        // 3. Update Camera Position based on calculated rotation and distance
        UpdateCameraPosition();
    }

    // --- Input System Event Handlers ---

    // This handles the 'R' key press
    private void OnResetViewPerformed(InputAction.CallbackContext context)
    {
        distance = defaultDistance;
        xRot = defaultXRot;
        yRot = defaultYRot;
        ResetRotationLimits();
    }

    // --- Control Logic Methods ---

    private void HandleRotation()
    {
        // Check if the EnableOrbit action (Right Mouse Button) is currently pressed
        if (enableOrbitAction.action != null && enableOrbitAction.action.IsPressed())
        {
            // Read the Vector2 delta value directly from the Look action
            Vector2 lookInput = lookAction.action.ReadValue<Vector2>();

            // Input delta is applied directly to rotation angles
            xRot += lookInput.x * rotationSpeed;
            yRot -= lookInput.y * rotationSpeed;
        }

        // Clamp the Y rotation to keep the camera from flipping over the top/bottom
        yRot = ClampAngle(yRot, yMinLimit, yMaxLimit);
    }

    private void HandleZoom()
    {
        if (zoomAction.action == null) return;

        // Read the Vector2 scroll value directly from the Zoom action
        Vector2 scrollDelta = zoomAction.action.ReadValue<Vector2>();

        // Only the Y-axis (vertical scroll) is used for zooming
        float zoomInput = scrollDelta.y;

        // Calculate the new distance using the Y scroll input
        distance -= zoomInput * zoomSpeed;

        // Clamp the distance
        distance = Mathf.Clamp(distance, minDistance, maxDistance);
    }

    private void UpdateCameraPosition()
    {
        // Create the rotation quaternion
        Quaternion rotation = Quaternion.Euler(yRot, xRot, 0);

        // Calculate the desired position based on target, rotation, and distance
        Vector3 position = target.position - (rotation * Vector3.forward * distance);

        // Apply position and rotation to the camera
        transform.rotation = rotation;
        transform.position = position;
    }

    private static float ClampAngle(float angle, float min, float max)
    {
        if (angle < -360)
            angle += 360;
        if (angle > 360)
            angle -= 360;
        return Mathf.Clamp(angle, min, max);
    }

    private void ResetRotationLimits()
    {
        xRot = ClampAngle(xRot, -360f, 360f);
        yRot = ClampAngle(yRot, yMinLimit, yMaxLimit);
    }
}