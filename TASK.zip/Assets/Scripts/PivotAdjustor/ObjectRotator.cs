using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Rotates the GameObject based on input from the new Input System,
/// typically used for creating an interactive 3D object viewer.
/// </summary>
public class ObjectRotator : MonoBehaviour
{
    [Range(0.1f, 2f)]
    public float rotationSensitivity = 0.3f;

    [Header("Input Action References")]
    [Tooltip("Mouse Delta (Look)")]
    public InputActionReference lookAction;
    [Tooltip("Mouse Scroll Wheel (Zoom)")]
    public InputActionReference zoomAction; 
    [Tooltip("Right Mouse Button (Enable Orbit)")]
    public InputActionReference enableOrbitAction; 
    [Tooltip("'R' Key (Reset View)")]
    public InputActionReference resetViewAction; 

    // Tracks if the orbit action is currently being held down.
    private bool isOrbitEnabled = false;

    public bool lookActionState = false;

    private PivotPlacer _pivotPlacer;


    private void Awake()
    {
        _pivotPlacer = FindFirstObjectByType<PivotPlacer>();
    }

    private void OnEnable()
    {
        // 1. Enable Look Action for continuous reading in Update
        if (lookAction != null && lookAction.action != null)
        {
            lookAction.action.Enable();
        }

        // 2. Enable Orbit Action and subscribe to its start/cancel events
        if (enableOrbitAction != null && enableOrbitAction.action != null)
        {
            enableOrbitAction.action.Enable();

            enableOrbitAction.action.started += EnableOrbit;
            enableOrbitAction.action.canceled += DisableOrbit;
        }
    }

    private void OnDisable()
    {
        // 1. Disable Look Action
        if (lookAction != null && lookAction.action != null)
        {
            lookAction.action.Disable();
        }

        // 2. Unsubscribe from Orbit Action events and disable it
        if (enableOrbitAction != null && enableOrbitAction.action != null)
        {
            enableOrbitAction.action.started -= EnableOrbit;
            enableOrbitAction.action.canceled -= DisableOrbit;
            enableOrbitAction.action.Disable();
        }
    }

    /// <summary>
    /// Called when the enableOrbitAction button is pressed down.
    /// </summary>
    private void EnableOrbit(InputAction.CallbackContext context)
    {
        isOrbitEnabled = true;
    }

    /// <summary>
    /// Called when the enableOrbitAction button is released.
    /// </summary>
    private void DisableOrbit(InputAction.CallbackContext context)
    {
        isOrbitEnabled = false;
    }

    void Update()
    {
        // Rotation is only allowed when the orbit action is held.
        if (!isOrbitEnabled)
        {
            return;
        }

        lookActionState = lookAction.action.enabled;

        // Check if the look action reference is set and the action is active
        if (lookAction == null || lookAction.action == null || !lookAction.action.enabled)
        {
            return;
        }

        // Read the input value directly from the action.
        Vector2 lookInput = lookAction.action.ReadValue<Vector2>();

        // Ensure we only process movement if there is actual input data
        if (lookInput != Vector2.zero && _pivotPlacer.isPivotSet)
        {
            // --- 1. Calculate Rotation Amounts ---

            // lookInput.x drives rotation around the Y-axis (Yaw)
            float rotationY = lookInput.x * rotationSensitivity;

            // lookInput.y drives rotation around the X-axis (Pitch/Tilt)
            float rotationX = -lookInput.y * rotationSensitivity;


            // --- 2. Apply Rotations ---

            // Apply Pitch (X-axis rotation) locally.
            transform.Rotate(Vector3.right, rotationX, Space.Self);

            // Apply Yaw (Y-axis rotation) globally.
            transform.Rotate(Vector3.up, rotationY, Space.World);
        }
    }
}