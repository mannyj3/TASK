using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class PivotPlacer : MonoBehaviour
{
    [SerializeField] private Button setPivotBUtton;
    [SerializeField] private GameObject objectRotator;
    [SerializeField] private GameObject modelToView;

    public bool isPivotSet = true;

    public InputActionReference leftMouseClick;

    private void OnEnable()
    {
        setPivotBUtton.onClick.AddListener(EnableSetPivot);
        leftMouseClick.action.performed += setPivotPosition;
    }

    private void OnDisable()
    {
        setPivotBUtton.onClick.RemoveAllListeners();
        leftMouseClick.action.performed -= setPivotPosition;
    }

    private void EnableSetPivot()
    {
        isPivotSet = false;

        //disable the object rotation here
        modelToView.transform.parent = transform.parent;
        leftMouseClick.action.Enable();


        setPivotBUtton.interactable = false;
        //objectRotator.GetComponent<ObjectRotator>().lookAction.action.Disable();
        //objectRotator.GetComponent<ObjectRotator>().enabled = false;
    }

    private void setPivotPosition(InputAction.CallbackContext context)
    {
        // 1. Read the mouse position from the context (it's typically a Vector2 screen position)
        // We assume the action is set up to read a Vector2 value (Pointer Position).
        Vector2 screenPosition = Mouse.current.position.ReadValue();

        // 2. Ensure we have a main camera reference
        Camera mainCamera = Camera.main;
        if (mainCamera == null)
        {
            return;
        }

        // 3. Create a ray from the screen position
        Ray ray = mainCamera.ScreenPointToRay(screenPosition);

        // RaycastHit will store the information about what was hit
        RaycastHit hit;

        // 4. Perform the raycast
        // Physics.Raycast returns true if the ray hits a collider

        if (!isPivotSet)
        {
            if (Physics.Raycast(ray, out hit))
            {
                // A hit occurred!
                // 5. Check if the rotator object is available
                if (objectRotator != null)
                {
                    // Set the position of the objectRotator to the exact point the ray hit the surface.
                    objectRotator.transform.position = hit.point;
                    setPivotBUtton.interactable = true;
                    
                    leftMouseClick.action.Disable();
                    isPivotSet = true;


                    modelToView.transform.parent = objectRotator.transform;
                    objectRotator.GetComponent<ObjectRotator>().enabled = false;
                    objectRotator.GetComponent<ObjectRotator>().lookAction.action.Disable();


                    objectRotator.GetComponent<ObjectRotator>().enabled = true;
                    objectRotator.GetComponent<ObjectRotator>().lookAction.action.Enable();
                }
            }
            else
            {
                // No hit occurred
            }
        }
    }
}
