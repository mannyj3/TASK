using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using System.Collections;
using TMPro;


public class UIController : MonoBehaviour
{
    [Header("Loading Screen")]
    [SerializeField] private TMP_Text loadingText;
    [SerializeField] private GameObject loadingScreen;
    [SerializeField] private GameObject objectToView;

    [Header("Buttons")]
    [SerializeField] private Button menu;
    [SerializeField] private Button controls;
    [SerializeField] private Button home;

    [Header("")]
    [SerializeField] private Button help;
    [SerializeField] private GameObject helpPanel;
    [SerializeField] private GameObject toolTip;

    [Header("")]
    [SerializeField] private Button visuals;
    [SerializeField] private Button visualsClose;
    [SerializeField] private GameObject visualsPanel;

    private bool isControlsPanelOpen = false;
    private bool isMenuPanelOpen = false;

    private void OnEnable()
    {
        controls.onClick.AddListener(ControlsButton);
        menu.onClick.AddListener(MenuButton);
        help.onClick.AddListener(HelpButton);
        visuals.onClick.AddListener(VisualsButton);
        visualsClose.onClick.AddListener(VisualsCloseButton);

        StartCoroutine(LoadingTextCoroutine());
    }

    private void OnDisable()
    {
        controls.onClick.RemoveAllListeners();
        menu.onClick.RemoveAllListeners();
        help.onClick.RemoveAllListeners();
        visuals.onClick.RemoveAllListeners();
        visualsClose.onClick.RemoveAllListeners();
    }


    private void ControlsButton()//Opens and closes the controls panel that contains the rotaion controls
    {
        if(!isControlsPanelOpen)
        {
            isControlsPanelOpen = true;
            AnimateObject.instance.AnimateMovePosition(controls.gameObject, Axis.Y_Axis, -462.354309f, 0.5f, null);
        }
        else
        {
           AnimateObject.instance.AnimateMovePosition(controls.gameObject, Axis.Y_Axis, -539.954346f, 0.5f, null);
            isControlsPanelOpen = false;
        }
    }

    private void MenuButton()//Opens and closes the menu panel
    {
        if(!isMenuPanelOpen)//close state
        {
            isMenuPanelOpen = true;
            AnimateObject.instance.AnimateMovePosition(menu.gameObject, Axis.X_Axis, -681.903442f, 0.5f, null);
        }
        else//open state
        {
            isMenuPanelOpen = false;
            AnimateObject.instance.AnimateMovePosition(menu.gameObject, Axis.X_Axis, -959.903442f, 0.5f, null);
        }
    }

    public void OpenCloseMenuPanel(bool open)//opens and closes the menu panel immediately
    {
        if(open)//open state
        {
            isMenuPanelOpen = true;
            AnimateObject.instance.AnimateMovePosition(menu.gameObject, Axis.X_Axis, -681.903442f, 0.01f, null);
        }
        else//close state
        {
            isMenuPanelOpen = false;
            AnimateObject.instance.AnimateMovePosition(menu.gameObject, Axis.X_Axis, -959.903442f, 0.01f, null);
        }
    }

    private void HelpButton()//opens the help button and activates the help on hover function
    {
        //helpPanel.SetActive(true);
        //toolTip.SetActive(true);
    }

    private void VisualsButton()
    {
        menu.gameObject.SetActive(false);
        OpenCloseMenuPanel(false);
        visualsPanel.SetActive(true);
    }

    private void VisualsCloseButton()
    {
        menu.gameObject.SetActive(true);
        visualsPanel.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        //if (helpPanel.activeInHierarchy && Mouse.current.leftButton.isPressed)
        //{
        //    helpPanel.SetActive(false);
        //    //toolTip.SetActive(false);
        //}
            
    }

    private IEnumerator LoadingTextCoroutine()
    {
        // --- Setup ---
        // Make sure 'loadingText' is assigned to your TextMeshPro component
        if (loadingText == null) yield break;

        // 1. FIX: Capture the starting time for the 2-second duration check.
        float startTime = Time.time;

        loadingText.gameObject.SetActive(true);
        string[] dots = {"", ".", "..", "..." };
        int dotIndex = 0;

        objectToView.SetActive(false);
        loadingScreen.SetActive(true);

        // --- Animation Loop ---
        // 2. FIX: The loop runs until the current time exceeds the start time plus 2 seconds.
        while (Time.time < startTime + 3f)
        {
            // 3. FIX: Concatenate the base text "Loading" with the dots at the current index.
            loadingText.text = "Loading" + dots[dotIndex];

            // Move to the next dot pattern, wrapping around
            dotIndex = (dotIndex + 1) % dots.Length;

            // Wait for the specified interval before the next update
            yield return new WaitForSeconds(0.3f);
        }

        loadingScreen.SetActive(false);
        objectToView.SetActive(true);
    }
}
