﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

    /// <summary>
    /// Dimension for objects
    /// </summary>
    public enum Axis
    {
        X_Axis,
        Y_Axis,
        Z_Axis
    };

public class AnimateObject : MonoBehaviour
{
    public static AnimateObject instance;
    private void Awake()
    {
        if (instance == null)
            instance = this;
    }

    /// <summary>
    /// Gets the axis that we defined in our Animate functionalities
    /// </summary>
    /// <param name="type"></param>
    /// <param name="objectRotation"></param>
    /// <returns></returns>
    private float GetStartAxis(Axis type, Vector3 vectorObject)
    {
        float startVector = 0.0f;
        switch (type)
        {
            case Axis.X_Axis:
                {
                    startVector = vectorObject.x;
                    break;
                }

            case Axis.Y_Axis:
                {
                    startVector = vectorObject.y;
                    break;
                }

            case Axis.Z_Axis:
                {
                    startVector = vectorObject.z;
                    break;
                }
        }
        return startVector;
    }

    /// <summary>
    /// Sets vector object axis values from lerpValue
    /// </summary>
    /// <param name="axis"></param>
    /// <param name="lerpValue"></param>
    /// <param name="vectorObject"></param>
    private void SetLerpValue(Axis axis, float lerpValue, ref Vector3 vectorObject)
    {
        switch (axis)
        {
            case Axis.X_Axis:
                {
                    vectorObject.x = lerpValue;
                    break;
                }

            case Axis.Y_Axis:
                {
                    vectorObject.y = lerpValue;
                    break;
                }

            case Axis.Z_Axis:
                {
                    vectorObject.z = lerpValue;
                    break;
                }
        }
    }

    private IEnumerator LerpRotate(GameObject rotateObject, Axis axis, float finishRotation, float time, Action callMethod = null)
    {
        float xValue = rotateObject.transform.localEulerAngles.x;
        xValue = (xValue > 180) ? xValue - 360 : xValue;
        float yValue = rotateObject.transform.localEulerAngles.y;
        yValue = (yValue > 180) ? yValue - 360 : yValue;
        float zValue = rotateObject.transform.localEulerAngles.z;
        zValue = (zValue > 180) ? zValue - 360 : zValue;

        float elapsedTime = 0;
        float startRotation = GetStartAxis(axis, rotateObject.transform.localEulerAngles);
        startRotation = (startRotation > 180) ? startRotation - 360 : startRotation;
        Vector3 rotationObject = rotateObject.transform.localEulerAngles;
        while (elapsedTime < time)
        {
            float LerpValue = Mathf.Lerp(startRotation, finishRotation, elapsedTime / time);
            SetLerpValue(axis, LerpValue, ref rotationObject);
            rotateObject.transform.localEulerAngles = rotationObject;
            elapsedTime += Time.deltaTime;
            yield return null;
        }
        FinalRotationValue(rotateObject, axis, finishRotation, xValue, yValue, zValue);
        if (callMethod != null)
            callMethod();
    }

    private void FinalRotationValue(GameObject gameObj, Axis axis, float targetValue, float xValue, float yValue, float zValue)
    {
        switch (axis)
        {
            case Axis.X_Axis:
                {
                    gameObj.transform.localRotation = Quaternion.Euler(targetValue, yValue, zValue);
                    break;
                }

            case Axis.Y_Axis:
                {
                    gameObj.transform.localRotation = Quaternion.Euler(xValue, targetValue, zValue);
                    break;
                }

            case Axis.Z_Axis:
                {
                    gameObj.transform.localRotation = Quaternion.Euler(xValue, yValue, targetValue);
                    break;
                }
        }
    }

    /// <summary>
    /// Rotates an object local euler angles using lerp
    /// </summary>
    /// <param name="gObject"></param>
    /// <param name="axis"></param>
    /// <param name="targetValue"></param>
    /// <param name="time"></param>
    /// <param name="callMethod"></param>
    public void AnimateRotate(GameObject gObject, Axis axis, float targetValue, float time, Action callMethod = null)
    {
        StartCoroutine(LerpRotate(gObject, axis, targetValue, time, callMethod));
    }


    private IEnumerator LerpMoveInOut(GameObject positionObject, Axis axis, float finishPos, float time, Action callMethod)
    {
        float elapsedTime = 0;
        float startPos = GetStartAxis(axis, positionObject.transform.localPosition);
        Vector3 initialPosition_1 = positionObject.transform.localPosition;
        while (elapsedTime < time)
        {
            float LerpValue = Mathf.Lerp(startPos, finishPos, (elapsedTime / time));
            SetLerpValue(axis, LerpValue, ref initialPosition_1);
            positionObject.transform.localPosition = initialPosition_1;
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        //yield return new WaitForSeconds(_time);

        Vector3 initialPosition_2 = positionObject.transform.localPosition;
        while (elapsedTime > 0)
        {
            float LerpValue = Mathf.Lerp(startPos, finishPos, (elapsedTime / time));
            SetLerpValue(axis, LerpValue, ref initialPosition_2);
            positionObject.transform.localPosition = initialPosition_2;
            elapsedTime -= Time.deltaTime;
            yield return null;
        }
        if (callMethod != null)
            callMethod();
    }

    /// <summary>
    /// Moves an object position In-Out using lerp
    /// </summary>
    /// <param name="gObject"></param>
    /// <param name="axis"></param>
    /// <param name="targetValue"></param>
    /// <param name="time"></param>
    /// <param name="callMethod"></param>
    public void AnimateInOutPosition(GameObject gObject, Axis axis, float targetValue, float time, Action callMethod = null)
    {
        StartCoroutine(LerpMoveInOut(gObject, axis, targetValue, time, callMethod));
    }

    private IEnumerator LerpMove(GameObject positionObject, Axis axis, float finishPos, float time, Action callMethod)
    {
        float xValue = positionObject.transform.localPosition.x;
        xValue = (xValue > 180) ? xValue - 360 : xValue;
        float yValue = positionObject.transform.localPosition.y;
        yValue = (yValue > 180) ? yValue - 360 : yValue;
        float zValue = positionObject.transform.localPosition.z;
        zValue = (zValue > 180) ? zValue - 360 : zValue;

        float elapsedTime = 0;
        float startPos = GetStartAxis(axis, positionObject.transform.localPosition);
        Vector3 newPosition = positionObject.transform.localPosition;
        while (elapsedTime < time)
        {
            float LerpValue = Mathf.Lerp(startPos, finishPos, (elapsedTime / time));
            SetLerpValue(axis, LerpValue, ref newPosition);
            positionObject.transform.localPosition = newPosition;
            elapsedTime += Time.deltaTime;
            yield return null;
        }
        //FinalPositionValue(positionObject, axis, finishPos, xValue, yValue, zValue);
        if (callMethod != null)
            callMethod();
    }

    private void FinalPositionValue(GameObject gameObj, Axis axis, float targetValue, float xValue, float yValue, float zValue)
    {
        switch (axis)
        {
            case Axis.X_Axis:
                {
                    gameObj.transform.localPosition = new Vector3(targetValue, yValue, zValue);
                    break;
                }

            case Axis.Y_Axis:
                {
                    gameObj.transform.localPosition = new Vector3(xValue, targetValue, zValue);
                    break;
                }

            case Axis.Z_Axis:
                {
                    gameObj.transform.localPosition = new Vector3(xValue, yValue, targetValue);
                    break;
                }
        }
    }

    /// <summary>
    /// Moves an object position using lerp
    /// </summary>
    /// <param name="gObject"></param>
    /// <param name="axis"></param>
    /// <param name="targetValue"></param>
    /// <param name="time"></param>
    /// <param name="callMethod"></param>
    public void AnimateMovePosition(GameObject gObject, Axis axis, float targetValue, float time, Action callMethod = null)
    {
        StartCoroutine(LerpMove(gObject, axis, targetValue, time, callMethod));
    }

    private void OnDestroy()
    {
        if (instance != null)
            instance = null;
    }

}