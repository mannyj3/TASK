using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem; // REQUIRED for the new Input System
using UnityEngine.EventSystems; // REQUIRED for IPointerEnter/Exit

/// <summary>
/// Attaches to a detection/trigger GameObject (like a Button) and controls the 
/// position and visibility of a separate 'targetToFollow' UI element 
/// when the mouse is hovering over the detector.
/// </summary>
public class MouseFollower : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Tooltip("The UI element (Image/Panel) that will follow the mouse.")]
    // NOTE: This MUST be the RectTransform of the UI element you want to move.
    public RectTransform targetToFollow;

    [Tooltip("The offset from the mouse cursor's screen position.")]
    public Vector2 offset = new Vector2(10, -25); // Default: slightly right and below

    // We no longer need rectTransform here, as we use targetToFollow.
    private Canvas canvas;
    private Camera canvasCamera;
    private bool isHovering = false;

    void Awake()
    {
        // Find the parent Canvas. This is crucial for coordinate conversion.
        canvas = GetComponentInParent<Canvas>();
        if (canvas == null)
        {
            Debug.LogError("MouseFollower must be a child of a Canvas.", this);
            enabled = false;
        }

        // Initial state: hide the follower object
        if (targetToFollow != null)
        {
            targetToFollow.gameObject.SetActive(false);
        }
    }

    // --- Hover Detection (Replacing OnEnable/OnDisable) ---

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (targetToFollow != null)
        {
            isHovering = true;
            // Set the target GameObject active only when hovering over this element.
            targetToFollow.gameObject.SetActive(true);

            // Set the camera context for coordinate conversion
            canvasCamera = canvas.worldCamera;
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (targetToFollow != null)
        {
            isHovering = false;
            // Hide the target GameObject when the mouse leaves.
            targetToFollow.gameObject.SetActive(false);
            canvasCamera = null;
        }
    }

    // --- Position Update ---
    void Update()
    {
        // Only move the target if we are currently hovering over the detector element
        if (!isHovering || targetToFollow == null || canvas == null || Mouse.current == null)
        {
            return;
        }

        // Get the current mouse position in screen coordinates
        Vector2 screenPoint = Mouse.current.position.ReadValue();

        Vector2 localPoint;
        RectTransform canvasRect = canvas.GetComponent<RectTransform>();

        // 1. Convert the current mouse screen position to a local position within the Canvas.
        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
            canvasRect,
            screenPoint,
            canvasCamera, // Use the stored camera
            out localPoint))
        {
            // 2. Apply the offset and set the target's local position
            targetToFollow.localPosition = localPoint + offset;
        }
    }
}